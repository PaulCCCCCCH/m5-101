import pickle
import json
import re

# 参照 Section 4 的代码，使用新的索引，搜索文件内容。

########################
### Section 7 Starts ###


### Section 7 Ends ###
######################